
#include "Color.h"

Color Red = Color(1.0f, 0.0f, 0.0f);
Color Green = Color(0.0f, 1.0f, 0.0f);
Color Blue = Color(0.0f, 0.0f, 1.0f);
Color Black = Color(0.0f, 0.0f, 0.0f);
Color White = Color(1.0f, 1.0f, 1.0f);
Color lightGray = Color(0.5f, 0.5f, 0.5f);
Color Gray = Color(0.3f, 0.3f, 0.3f);
Color Yellow = Color(1.0f, 0.9f, 0.0f);
Color Orange = Color(1.7f, 0.7f, 0.1f);