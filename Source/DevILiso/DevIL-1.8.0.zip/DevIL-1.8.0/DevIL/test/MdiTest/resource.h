//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WindowsTest.rc
//
#define IDC_MYICON                      2
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDC_OPENIL                      109
#define IDR_MAINFRAME                   128
#define IDI_ICON1                       155
#define IDI_ICON2                       156
#define IDI_ICON3                       157
#define IDI_ICON4                       158
#define IDI_ICON5                       159
#define IDI_ICON6                       160
#define IDI_ICON7                       161
#define IDI_ICON8                       162
#define IDI_ICON9                       163
#define IDI_ICON11                      165
#define IDI_ICON12                      166
#define IDR_MENU1                       167
#define IDD_DIALOG_ABOUT                168
#define IDD_DIALOG_FILTER               169
#define IDD_DIALOG_RESIZE               170
#define IDC_ABOUT_VENDOR                1001
#define IDC_ABOUT_VER_STRING            1002
#define IDC_ABOUT_VER_NUM               1003
#define IDC_FILTER_EDIT                 1004
#define IDC_FILTER_DESC_TEXT            1005
#define IDC_ERROR1                      1014
#define IDC_ERROR2                      1015
#define IDC_EDIT_RESIZE_X               1015
#define IDC_ERROR3                      1016
#define IDC_EDIT_RESIZE_Y               1016
#define IDC_ERROR4                      1017
#define IDC_EDIT_RESIZE_Z               1017
#define IDC_ERROR5                      1018
#define IDC_ERROR6                      1019
#define IDC_OPENIL_LINK                 1020
#define ID_FILE_EXIT                    32771
#define ID_HELP_ABOUT                   32772
#define ID_CONVERT_RGB                  32773
#define ID_CONVERT_RGBA                 32774
#define ID_CONVERT_BGR                  32775
#define ID_CONVERT_BGRA                 32776
#define ID_CONVERT_LUMINANCE            32777
#define ID_FILE_LOAD                    32778
#define ID_FILE_SAVE                    32779
#define ID_FILTER_BITFILTER1            32780
#define ID_FILTER_BITFILTER2            32781
#define ID_FILTER_BITFILTER3            32782
#define ID_FILTER_EMBOSS                32783
#define ID_FILTER_NOISE                 32784
#define ID_FILTER_PIXELIZE              32785
#define ID_EFFECTS_FILTERS_SCALE        32786
#define ID_EFFECTS_FILTERS_EDGEDETECT_SOBEL 32787
#define ID_EFFECTS_FILTERS_EDGEDETECT_PREWITT 32788
#define ID_EDIT_UNDO                    32789
#define ID_EDIT_UNDOLEVEL               32790
#define ID_FILTERS_BLUR_AVERAGE         32791
#define ID_FILTERS_BLUR_GAUSSIAN        32792
#define ID_FILTER_GAMMACORRECT          32793
#define ID_FILTER_ALIENIFY              32794
#define ID_FILTER_SHARPEN               32795
#define ID_FILTER_NEGATIVE              32796
#define ID_EFFECTS_FLIP                 32797
#define ID_EFFECTS_MIRROR               32798
#define ID_EFFECTS_COUNTCOLORS          32799
#define ID_EDIT_COPY                    32800
#define ID_EDIT_PASTE                   32801
#define ID_EFFECTS_FILTERS_ROTATE       32802
#define ID_EFFECTS_FILTERS_EDGEDETECT_EMBOSS 32804
#define ID_FILE_PRINT                   32805
#define ID_EDIT_VIEWMIPMAP              32806
#define ID_EDIT_VIEWIMAGENUM            32807
#define ID_FILE_OPENURL                 32808
#define ID_CONVERT_PALETTE              32809
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        181
#define _APS_NEXT_COMMAND_VALUE         32810
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
