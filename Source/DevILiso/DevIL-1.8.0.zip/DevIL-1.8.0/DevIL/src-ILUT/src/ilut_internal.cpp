//-----------------------------------------------------------------------------
//
// ImageLib Utility Toolkit Sources
// Copyright (C) 2000-2017 by Denton Woods
// Last modified: 05/15/2002
//
// Filename: src-ILUT/src/ilut_internal.cpp
//
// Description: Internal stuff for ILUT
//
//-----------------------------------------------------------------------------


#include "ilut_internal.h"

//#if !defined(__APPLE__)
	ILimage *ilutCurImage = NULL;
//#endif
